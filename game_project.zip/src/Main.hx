package;

import openfl.display.MovieClip;
import openfl.display.Sprite;
import openfl.events.Event;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.utils.Assets;

class Main extends Sprite {
	var msg:TextField;

	public function new() {
		super();

		msg = new TextField();
		msg.defaultTextFormat = new TextFormat("_sans", 20, 0xFFFFFF);
		msg.multiline = true;
		msg.wordWrap = true;
		msg.width = 600;
		msg.text = "Cargando SWF...";
		addChild(msg);

		if (stage != null) {
			start(null);
		} else {
			addEventListener(Event.ADDED_TO_STAGE, start);
		}
	}

	function start(_:Event):Void {
		removeEventListener(Event.ADDED_TO_STAGE, start);
		Assets.loadLibrary("game").onComplete(function(_) {
			try {
				var tl:MovieClip = Assets.getMovieClip("game:");
				if (tl == null) {
					fail("Assets.getMovieClip('game:') devolvio null");
					return;
				}
				removeChild(msg);
				addChild(new Game(tl));
			} catch (e:Dynamic) {
				fail(e);
			}
		}).onError(function(e:Dynamic) {
			fail(e);
		});
	}

	function fail(e:Dynamic):Void {
		msg.text = "ERROR al cargar: " + Std.string(e);
		trace(msg.text);
	}
}
