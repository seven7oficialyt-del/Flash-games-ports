package;

import openfl.display.Sprite;
import openfl.text.TextField;

// Sustituye a un TextField del SWF: mismo sitio, centrado, mismo color.
class NumText extends Sprite {
	var src:TextField;
	var color:Int;
	var last:String = null;

	public function new(t:TextField, c:Int) {
		super();
		src = t;
		color = c;
		mouseEnabled = false;
		t.visible = false;
	}

	public function set(v:String):Void {
		if (v == last) {
			return;
		}
		last = v;
		var size = 33.0;
		var s = size / Karloff.EM;
		var total = 0.0;
		for (i in 0...v.length) {
			var a = Karloff.ADV.get(v.charAt(i));
			total += (a == null) ? 0 : a * s;
		}
		var x = src.x + (src.width - total) / 2;
		var y = src.y + 2 + Karloff.ASC * s;
		graphics.clear();
		graphics.beginFill(color, 1);
		for (i in 0...v.length) {
			var ch = v.charAt(i);
			Karloff.draw(graphics, ch, x, y, s);
			var a = Karloff.ADV.get(ch);
			x += (a == null) ? 0 : a * s;
		}
		graphics.endFill();
	}
}
