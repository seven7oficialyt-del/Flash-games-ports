package;

import openfl.Assets;
import openfl.media.Sound;
import openfl.media.SoundChannel;
import openfl.media.SoundTransform;

/*
 * Sonidos extraidos del SWF original (assets/sounds/s<ID>.wav, ID = id del
 * DefineSound en el SWF). Se cargan una sola vez al inicio.
 */
class Snd {
	static var cache:Map<Int, Sound> = new Map();
	static var musicCh:SoundChannel;
	static var brakeCh:SoundChannel;
	static var brakeOn:Bool = false;

	static var ids:Array<Int> = [
		1, 2, 3, 4, 47, 65, 68, 79, 80, 128, 142, 147, 179, 180, 185, 186, 187, 188, 225, 232, 242, 248, 249, 256, 258, 302, 305, 330, 355, 366,
		367, 385, 416, 437
	];

	public static function init():Void {
		for (i in ids) {
			get(i);
		}
	}

	static function get(id:Int):Sound {
		if (cache.exists(id)) {
			return cache.get(id);
		}
		var s:Sound = null;
		try {
			s = Assets.getSound("assets/sounds/s" + id + ".wav");
		} catch (e:Dynamic) {
			s = null;
		}
		cache.set(id, s);
		return s;
	}

	public static function play(id:Int):Void {
		if (id <= 0) {
			return;
		}
		var s = get(id);
		if (s == null) {
			return;
		}
		try {
			s.play();
		} catch (e:Dynamic) {}
	}

	public static function music(id:Int):Void {
		stopMusic();
		var s = get(id);
		if (s == null) {
			return;
		}
		try {
			musicCh = s.play(0, 9999, new SoundTransform(0.6));
		} catch (e:Dynamic) {}
	}

	static function stopMusic():Void {
		if (musicCh != null) {
			try {
				musicCh.stop();
			} catch (e:Dynamic) {}
			musicCh = null;
		}
	}

	// Chirrido de frenos (export "frenos" = sonido 4): suena mientras se frena.
	public static function brake(on:Bool):Void {
		if (on == brakeOn) {
			return;
		}
		brakeOn = on;
		if (on) {
			var s = get(4);
			if (s != null) {
				try {
					brakeCh = s.play(0, 9999, new SoundTransform(0.8));
				} catch (e:Dynamic) {}
			}
		} else {
			stopBrake();
		}
	}

	static function stopBrake():Void {
		if (brakeCh != null) {
			try {
				brakeCh.stop();
			} catch (e:Dynamic) {}
			brakeCh = null;
		}
		brakeOn = false;
	}

	public static function stopAll():Void {
		stopMusic();
		stopBrake();
	}
}
