package;

import openfl.Lib;
import openfl.display.DisplayObject;
import openfl.display.MovieClip;
import openfl.display.Sprite;
import openfl.events.Event;
import openfl.events.KeyboardEvent;
import openfl.events.MouseEvent;
import openfl.events.TouchEvent;
import openfl.geom.Matrix;
import openfl.geom.Rectangle;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFormatAlign;
import openfl.ui.Multitouch;
import openfl.ui.MultitouchInputMode;

/*
 * Port a Haxe/OpenFL de "Scooby-Doo SpookySpeed" (SWF en ActionScript 2).
 *
 * Los graficos salen del SWF original (libreria swf). El ActionScript NO se
 * ejecuta: toda la logica esta reescrita aqui, traducida de los scripts
 * extraidos (frame 13 = funciones aros/obstaculos, directores de nivel,
 * controlador de freno, auto, sombra y flujo de pantallas).
 *
 * Fotogramas de la linea de tiempo original:
 *   9 titulo | 11 instrucciones | 13/19/25 intro de nivel | 14/20/26 juego
 *   17/23/29 choque | 33-35 game over | 31 final | 37 atajo
 */

typedef Tr = {x:Float, y:Float, sx:Float, sy:Float, rot:Float};

class Obs {
	public var mc:MovieClip;
	public var name:String;
	public var sc:Float = 5;
	public var sale:Bool = false;
	public var h:Int = 0;
	public var punt:Int = 0;
	public var snack:Bool = false;
	public var atajo:Bool = false;
	public var abajo:Bool = false;
	public var mostro:Int = 0;
	public var state:Int = 0; // 0 reposo, 1 aparece (monstruos), 2 golpeado
	public var f:Int = 1;
	public var total:Int = 1;
	public var hitFrame:Int = 2;
	public var appearEnd:Int = 0;
	public var hitRect:DisplayObject;
	public var shadow:DisplayObject;
	public var alpha100:Float = 100;
	public var lastFrame:Int = -1;
	public var tr:Tr;
	public var mancha:Shot;

	public function new() {}
}

class Shot {
	public var mc:MovieClip;
	public var f:Int = 1;
	public var running:Bool = false;

	public function new(m:MovieClip) {
		mc = m;
	}

	public function start():Void {
		running = true;
		f = 2;
	}

	public function tick():Void {
		if (mc == null) {
			return;
		}
		if (running) {
			f++;
			if (f > mc.totalFrames) {
				running = false;
				f = 1;
			}
		}
		mc.gotoAndStop(f);
	}
}

// Sprite 41 del SWF: fundido. Fotogramas 1-10 entra, 10-19 sale.
class FadeAnim {
	public var mc:MovieClip;
	public var mode:Int = 0; // 0 sin clip, 1 entra, 2 quieto, 3 sale
	var f:Int = 1;
	var cb:Void->Void;

	public function new() {}

	public function start(m:MovieClip):Void {
		mc = m;
		f = 1;
		cb = null;
		mode = (m == null) ? 0 : 1;
		show();
	}

	function show():Void {
		if (mc != null) {
			mc.gotoAndStop(f);
		}
	}

	public function exit(c:Void->Void):Void {
		if (mode == 3) {
			return;
		}
		if (mc == null) {
			c();
			return;
		}
		cb = c;
		mode = 3;
		f = 10;
		show();
	}

	public function tick():Void {
		if (mc == null) {
			return;
		}
		if (mode == 1) {
			f++;
			if (f >= 10) {
				f = 10;
				mode = 2;
			}
			show();
		} else if (mode == 3) {
			f++;
			if (f >= 19) {
				f = 19;
				show();
				var x = cb;
				cb = null;
				mode = 0;
				if (x != null) {
					x();
				}
				return;
			}
			show();
		}
	}
}

class Btn extends Sprite {
	public var down:Bool = false;
	public var pid:Int = -1;
	public var onPress:Void->Void;

	var tf:TextField;
	var lastPress:Int = -10000;

	public function new(text:String) {
		super();
		tf = new TextField();
		var fmt = new TextFormat("_sans", 34, 0xFFFFFF, true);
		fmt.align = TextFormatAlign.CENTER;
		tf.defaultTextFormat = fmt;
		tf.text = text;
		tf.selectable = false;
		tf.mouseEnabled = false;
		addChild(tf);
		addEventListener(MouseEvent.MOUSE_DOWN, onMouseDown);
		addEventListener(TouchEvent.TOUCH_BEGIN, onTouchBegin);
	}

	function onMouseDown(e:MouseEvent):Void {
		down = true;
		press();
	}

	function onTouchBegin(e:TouchEvent):Void {
		down = true;
		pid = e.touchPointID;
		press();
	}

	// Algunas plataformas envian raton Y toque para el mismo dedo: se ignora el segundo.
	function press():Void {
		var t = Lib.getTimer();
		if (t - lastPress < 400) {
			return;
		}
		lastPress = t;
		if (onPress != null) {
			onPress();
		}
	}

	public function release():Void {
		down = false;
		pid = -1;
	}

	public function resize(w:Float, h:Float):Void {
		graphics.clear();
		graphics.beginFill(0xFFFFFF, 0.28);
		graphics.drawRoundRect(0, 0, w, h, 28, 28);
		graphics.endFill();
		tf.width = w;
		tf.height = h;
		tf.y = (h - 44) / 2;
	}
}

class Game extends Sprite {
	static inline var W:Int = 432;
	static inline var H:Int = 330;
	static inline var DEBUG:Bool = false;

	static inline var M_TITLE:Int = 1;
	static inline var M_INSTR:Int = 2;
	static inline var M_INTRO:Int = 3;
	static inline var M_PLAY:Int = 4;
	static inline var M_CRASH:Int = 5;
	static inline var M_OVER:Int = 6;
	static inline var M_END:Int = 7;
	static inline var M_SHORT:Int = 8;
	static inline var M_VIEW:Int = 9;

	static var SND_TITLE:Array<Array<Int>> = [[1, 4], [20, 65], [22, 68], [31, 79], [47, 80], [85, 47], [90, 79]];
	static var SND_I1:Array<Array<Int>> = [[2, 179], [2, 180], [52, 185], [52, 186], [57, 186], [57, 187], [63, 180], [79, 185], [79, 188]];
	static var SND_I2:Array<Array<Int>> = [[2, 305], [2, 180], [52, 185], [52, 186], [57, 186], [63, 180], [79, 185], [79, 188]];
	static var SND_I3:Array<Array<Int>> = [[2, 366], [2, 180], [52, 185], [52, 186], [57, 186], [63, 180], [71, 367], [79, 185], [79, 188]];

	var sndTimer:Int = 0;
	var lastSp:String = null;
	var lastTm:String = null;
	var tl:MovieClip;
	var world:Sprite;
	var dbg:TextField;
	var ui:Sprite;
	var btnLeft:Btn;
	var btnRight:Btn;
	var btnBrake:Btn;
	var btnInfo:Btn;
	var btnDbg:Btn;

	var fadeAnim:FadeAnim = new FadeAnim();
	var mode:Int = 0;
	var modeBeforeView:Int = M_TITLE;
	var cur:Int = 9;
	var viewFrame:Int = 1;
	var menuTimer:Int = 0;
	var lastTap:Int = -10000;
	var uiW:Float = -1;
	var uiH:Float = -1;
	var errText:String = "";
	var keyLeft:Bool = false;
	var keyRight:Bool = false;
	var keyDown:Bool = false;

	// ---- variables globales del ActionScript original ("/:nombre") ----
	var puntos:Int = 0;
	var gana:Int = 0;
	var ganar:Int = 0;
	var perder:Int = 0;
	var over:Int = 0;
	var shortcut:Int = 0;
	var nivel:Int = 1;
	var maximo:Float = 10;
	var minimo:Float = 20;
	var scale1:Float = 5;
	var scale2:Float = 140;
	var scale3:Float = 500;
	var acelera:Float = 20;
	var ancho:Float = 432;
	var alto:Float = 330;
	var depth:Float = 200;
	var cuenta:Int = 0;
	var energia:Int = 4;
	var vidas:Int = 3;
	var tiempo:Int = 100;
	var curva:Int = 0;
	var freno:Float = 0;
	var frenar:Int = 0;
	var choque:Int = 0;
	var bien:Int = 0;
	var velc:Float = 8;
	var target:Float = 0;
	var accel:Float = 0;
	var convert:Float = 0;
	var aconvert:Float = 0;
	var rot:Float = 0;

	// ---- estado del nivel ----
	var level:Int = 1;
	var levelEnding:Bool = false;
	var timerTick:Int = 0;
	var reactTimer:Int = 0;
	var lastPers:String = "";
	var chispasF:Int = 1;
	var cache:Map<String, Tr> = new Map();
	var zmap:Map<DisplayObject, Float> = new Map();
	var obs:Array<Obs> = [];
	var stripes:Array<MovieClip> = [];
	var stripeTr:Array<Tr> = [];
	var shots:Array<Shot> = [];
	var car:MovieClip;
	var carTr:Tr;
	var carSub:MovieClip;
	var carShadow:MovieClip;
	var carHit:DisplayObject;
	var chispas:MovieClip;
	var pers:MovieClip;
	var sombra:MovieClip;
	var sombraTr:Tr;
	var hud:MovieClip;
	var hudLives:MovieClip;
	var hudEnergy:MovieClip;
	var hudLevel:MovieClip;
	var hudTimer:MovieClip;
	var hudNeedle:MovieClip;
	var hudScoreTf:Array<TextField> = [];
	var hudTimeTf:Array<TextField> = [];

	public function new(timeline:MovieClip) {
		super();
		tl = timeline;
		addEventListener(Event.ADDED_TO_STAGE, init);
	}

	function init(_:Event):Void {
		removeEventListener(Event.ADDED_TO_STAGE, init);

		Snd.init();
		world = new Sprite();
		world.scrollRect = new Rectangle(0, 0, W, H);
		world.addChild(tl);
		addChild(world);

		ui = new Sprite();
		addChild(ui);
		btnLeft = new Btn("<");
		btnRight = new Btn(">");
		btnBrake = new Btn("FRENO");
		btnInfo = new Btn("INFO");
		btnDbg = new Btn("DBG");
		for (b in [btnLeft, btnRight, btnBrake, btnInfo, btnDbg]) {
			ui.addChild(b);
		}
		btnInfo.onPress = function() {
			if (mode == M_TITLE && fadeAnim.mode != 3) {
				exitTo(11);
			}
		};
		btnDbg.onPress = onDbg;
		btnDbg.visible = DEBUG;

		dbg = new TextField();
		dbg.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFF00);
		dbg.multiline = true;
		dbg.wordWrap = true;
		dbg.mouseEnabled = false;
		dbg.selectable = false;
		dbg.visible = DEBUG;
		addChild(dbg);

		if (Multitouch.supportsTouchEvents) {
			Multitouch.inputMode = MultitouchInputMode.TOUCH_POINT;
		}
		stage.addEventListener(Event.RESIZE, onResize);
		stage.addEventListener(KeyboardEvent.KEY_DOWN, onKeyDown);
		stage.addEventListener(KeyboardEvent.KEY_UP, onKeyUp);
		stage.addEventListener(MouseEvent.MOUSE_UP, onMouseUp);
		stage.addEventListener(TouchEvent.TOUCH_END, onTouchEnd);
		stage.addEventListener(MouseEvent.CLICK, onTap);
		stage.addEventListener(TouchEvent.TOUCH_BEGIN, onTouchTap);
		stage.addEventListener(Event.ENTER_FRAME, onTick);
		onResize(null);

		go(9);
	}

	// ======================= pantallas =======================

	function go(frame:Int):Void {
		cur = frame;
		tl.gotoAndStop(frame);
		menuTimer = 0;
		sndTimer = 0;
		Snd.stopAll();
		zmap = new Map();
		fadeAnim.start(findFade());
		switch (frame) {
			case 9:
				mode = M_TITLE;
			case 11:
				mode = M_INSTR;
			case 13, 19, 25:
				mode = M_INTRO;
				level = (frame == 13) ? 1 : ((frame == 19) ? 2 : 3);
				introSetup();
			case 14, 20, 26:
				mode = M_PLAY;
				level = (frame == 14) ? 1 : ((frame == 20) ? 2 : 3);
				initPlay();
				Snd.music(level == 1 ? 3 : (level == 2 ? 2 : 1));
			case 17, 23, 29:
				mode = M_CRASH;
				Snd.play(302);
			case 31:
				mode = M_END;
				Snd.play(142);
			case 33, 34, 35:
				mode = M_OVER;
				Snd.play(437);
			case 37:
				mode = M_SHORT;
				Snd.play(142);
			default:
				mode = M_INSTR;
		}
		fireSched();
		layoutUi();
	}

	function fireSched():Void {
		var tab:Array<Array<Int>> = null;
		if (mode == M_TITLE) {
			tab = SND_TITLE;
		} else if (mode == M_INTRO) {
			tab = (level == 1) ? SND_I1 : ((level == 2) ? SND_I2 : SND_I3);
		}
		if (tab == null) {
			return;
		}
		for (e in tab) {
			if (e[0] - 1 == sndTimer) {
				Snd.play(e[1]);
			}
		}
	}

	static function hitSound(n:String):Int {
		if (n.indexOf("barrera") == 0) return 225;
		if (n.indexOf("lampara") == 0) return 232;
		if (n.indexOf("zombie") == 0) return 249;
		if (n.indexOf("dinamita") == 0) return 256;
		if (n.indexOf("snack") == 0) return 258;
		if (n.indexOf("hielo") == 0) return 330;
		if (n.indexOf("raiz") == 0) return 385;
		if (n.indexOf("titas3") == 0) return 256;
		if (n.indexOf("titas") == 0) return 242;
		if (n.indexOf("dracula") == 0) return 80;
		if (n.indexOf("pantano") == 0) return 416;
		if (n.indexOf("roca") == 0 || n.indexOf("bola") == 0) return 256;
		return 0;
	}

	function persSound(label:String):Void {
		switch (label) {
			case "sube":
				Snd.play(79);
			case "baja":
				Snd.play(142);
			case "mal1", "mal2":
				Snd.play(147);
			default:
		}
	}

	static inline function gf(m:MovieClip, f:Int):Void {
		if (m.currentFrame != f) {
			m.gotoAndStop(f);
		}
	}

	// Cache de mapa de bits: el vector del SWF se rasteriza UNA vez (no en cada
	// fotograma al escalar), y la GPU lo escala. Es lo que mas acelera el juego.
	static function cacheMc(m:DisplayObject):Void {
		m.cacheAsBitmap = true;
		m.cacheAsBitmapMatrix = new Matrix(2.5, 0, 0, 2.5);
	}

	function findFade():MovieClip {
		for (n in ["fade", "fade2", "fadei", "fader", "fadel", "fade8"]) {
			var m = mcOf(n);
			if (m != null) {
				return m;
			}
		}
		return null;
	}

	function mcOf(name:String):MovieClip {
		var d = tl.getChildByName(name);
		return (d == null) ? null : Std.downcast(d, MovieClip);
	}

	function exitTo(frame:Int):Void {
		fadeAnim.exit(function() go(frame));
	}

	function introSetup():Void {
		// Equivale a los DoAction de los fotogramas 13 / 19 / 25.
		if (level == 1) {
			puntos = 0;
			gana = 0;
			ganar = 0;
			perder = 0;
			over = 0;
			shortcut = 0;
			nivel = 1;
			maximo = 10;
			minimo = 20;
			acelera = minimo;
			cuenta = 0;
			energia = 4;
			vidas = 3;
			tiempo = 100;
		} else {
			cuenta = 0;
			tiempo = 100;
			ganar = 0;
			gana = 0;
			nivel = level;
			if (level == 3) {
				maximo = 7.5;
				minimo = 17.5;
			}
		}
	}

	function playFrame():Int {
		return (nivel == 1) ? 14 : ((nivel == 2) ? 20 : 26);
	}

	function confirm():Void {
		if (fadeAnim.mode == 3) {
			return;
		}
		switch (mode) {
			case M_TITLE, M_INSTR:
				exitTo(13);
			case M_INTRO:
				exitTo(playFrame());
			case M_CRASH:
				exitTo(retryPlay());
			case M_OVER, M_END:
				exitTo(9);
			case M_SHORT:
				exitTo(nivel == 1 ? 19 : 25);
			default:
		}
	}

	// Fotograma 18/24/30: perder=0, energia=4, tiempo-10, vuelve a jugar.
	function retryPlay():Int {
		perder = 0;
		energia = 4;
		if (tiempo > 10) {
			tiempo -= 10;
		} else {
			tiempo = 100;
		}
		return playFrame();
	}

	// ======================= entrada =======================

	function onKeyDown(e:KeyboardEvent):Void {
		switch (e.keyCode) {
			case 37:
				keyLeft = true;
			case 39:
				keyRight = true;
			case 40:
				keyDown = true;
			case 32:
				confirm();
			case 73:
				if (mode == M_TITLE) {
					exitTo(11);
				}
			case 86:
				onDbg();
			default:
		}
	}

	function onKeyUp(e:KeyboardEvent):Void {
		switch (e.keyCode) {
			case 37:
				keyLeft = false;
			case 39:
				keyRight = false;
			case 40:
				keyDown = false;
			default:
		}
	}

	function onMouseUp(e:MouseEvent):Void {
		for (b in [btnLeft, btnRight, btnBrake]) {
			b.release();
		}
	}

	function onTouchEnd(e:TouchEvent):Void {
		for (b in [btnLeft, btnRight, btnBrake]) {
			if (b.pid == e.touchPointID) {
				b.release();
			}
		}
	}

	function onTap(e:MouseEvent):Void {
		if (!Std.isOfType(e.target, Btn)) {
			tapAt(e.stageX);
		}
	}

	function onTouchTap(e:TouchEvent):Void {
		if (!Std.isOfType(e.target, Btn)) {
			tapAt(e.stageX);
		}
	}

	function tapAt(x:Float):Void {
		var now = Lib.getTimer();
		if (now - lastTap < 300) {
			return;
		}
		lastTap = now;
		if (mode == M_VIEW) {
			viewFrame += (x < stage.stageWidth / 2) ? -1 : 1;
			if (viewFrame < 1) {
				viewFrame = tl.totalFrames;
			}
			if (viewFrame > tl.totalFrames) {
				viewFrame = 1;
			}
			tl.gotoAndStop(viewFrame);
			return;
		}
		if (mode != M_PLAY) {
			confirm();
		}
	}

	function onDbg():Void {
		if (mode == M_VIEW) {
			mode = modeBeforeView;
			go(cur);
		} else {
			modeBeforeView = mode;
			mode = M_VIEW;
			viewFrame = cur;
		}
	}

	function onResize(_:Event):Void {
		var sw = stage.stageWidth;
		var sh = stage.stageHeight;
		var s = Math.min(sw / W, sh / H);
		world.scaleX = world.scaleY = s;
		world.x = (sw - W * s) / 2;
		world.y = (sh - H * s) / 2;
		dbg.width = sw;
		layoutUi();
	}

	function layoutUi():Void {
		if (stage == null || btnLeft == null) {
			return;
		}
		var sw = stage.stageWidth;
		var sh = stage.stageHeight;
		var bw = Math.min(sw, sh) * 0.30;
		var bh = bw * 0.7;
		var m = 16.0;
		if (sw != uiW || sh != uiH) {
			uiW = sw;
			uiH = sh;
			btnLeft.resize(bw, bh);
			btnRight.resize(bw, bh);
			btnBrake.resize(bw * 1.2, bh);
			btnInfo.resize(bw * 0.8, bh * 0.6);
			btnDbg.resize(bw * 0.6, bh * 0.5);
		}
		btnLeft.x = m;
		btnLeft.y = sh - bh - m;
		btnRight.x = m * 2 + bw;
		btnRight.y = sh - bh - m;
		btnBrake.x = sw - bw * 1.2 - m;
		btnBrake.y = sh - bh - m;
		btnInfo.x = sw - bw * 0.8 - m;
		btnInfo.y = sh - bh * 0.6 - m;
		btnDbg.x = sw - bw * 0.6 - m;
		btnDbg.y = m + 30;
		var play = (mode == M_PLAY);
		btnLeft.visible = btnRight.visible = btnBrake.visible = play;
		btnInfo.visible = (mode == M_TITLE);
	}

	// ======================= bucle principal =======================

	function onTick(_:Event):Void {
		try {
			layoutUi();
			if (mode == M_TITLE || mode == M_INTRO) {
				sndTimer++;
				fireSched();
			}
			if (mode != M_VIEW) {
				fadeAnim.tick();
			}
			switch (mode) {
				case M_PLAY:
					tickPlay();
				case M_INTRO:
					menuTimer++;
					if (menuTimer == ((level == 3) ? 90 : 91)) {
						confirm();
					}
				case M_CRASH:
					menuTimer++;
					if (menuTimer == 60) {
						confirm();
					}
				case M_SHORT:
					menuTimer++;
					if (menuTimer == 35) {
						confirm();
					}
				default:
			}
		} catch (ex:Dynamic) {
			errText = "ERROR: " + Std.string(ex);
		}
		if (DEBUG) {
			var t = "fr " + cur + " modo " + mode + " niv " + nivel + " cuenta " + cuenta + " acel " + Std.int(acelera) + " en " + energia + " vid " + vidas + " pts " + puntos + " t " + tiempo;
			if (mode == M_VIEW) {
				t = "VISOR fotograma " + viewFrame + "/" + tl.totalFrames + " hijos: ";
				for (i in 0...Std.int(Math.min(tl.numChildren, 14))) {
					t += tl.getChildAt(i).name + " ";
				}
			}
			dbg.text = t + "\n" + errText;
		}
	}

	// ======================= juego =======================

	function placed(key:String, d:DisplayObject):Tr {
		var k = level + ":" + key;
		var t = cache.get(k);
		if (t == null) {
			t = {x: d.x, y: d.y, sx: d.scaleX, sy: d.scaleY, rot: d.rotation};
			cache.set(k, t);
		} else {
			d.x = t.x;
			d.y = t.y;
			d.scaleX = t.sx;
			d.scaleY = t.sy;
			d.rotation = t.rot;
		}
		return t;
	}

	function initPlay():Void {
		// DoAction de los fotogramas 14 / 20 / 26. 'cuenta' NO se reinicia (igual que el original).
		curva = 0;
		freno = 0;
		frenar = 0;
		bien = 0;
		choque = 0;
		velc = 8;
		rot = 0;
		target = 0;
		accel = 0;
		convert = 0;
		aconvert = 0;
		levelEnding = false;
		timerTick = 0;
		reactTimer = 0;
		lastPers = "";
		chispasF = 1;
		errText = "";
		lastSp = null;
		lastTm = null;
		obs = [];
		stripes = [];
		stripeTr = [];
		shots = [];

		car = mcOf("carro");
		sombra = mcOf("sombra");
		hud = mcOf("interfaz");
		if (car == null) {
			errText = "ERROR: no se encontro el clip 'carro' en el fotograma " + cur;
			return;
		}
		car.stop();
		car.gotoAndStop(1);
		carTr = placed("carro", car);
		carSub = Std.downcast(car.getChildByName("carro"), MovieClip);
		carShadow = Std.downcast(car.getChildByName("sombra"), MovieClip);
		chispas = Std.downcast(car.getChildByName("chispas"), MovieClip);
		pers = Std.downcast(car.getChildByName("personajes"), MovieClip);
		carHit = car.getChildByName("hit");
		if (carHit != null) {
			carHit.alpha = 0;
		}
		if (carSub != null) {
			carSub.gotoAndStop(level == 1 ? 1 : (level == 2 ? 4 : 6));
		}
		if (carShadow != null) {
			carShadow.gotoAndStop(level == 2 ? 2 : 1);
		}
		if (chispas != null) {
			chispas.gotoAndStop(1);
		}
		if (pers != null) {
			pers.gotoAndStop(1);
		}
		if (sombra != null) {
			sombra.stop();
			sombraTr = placed("sombra", sombra);
		}

		for (i in 1...7) {
			var s = mcOf(Std.string(i));
			if (s != null) {
				s.gotoAndStop((i % 2 == 0) ? 2 : 1);
				cacheMc(s);
				stripes.push(s);
				stripeTr.push(placed("raya" + i, s));
			}
		}

		var special = ["carro", "sombra", "interfaz", "fade", "fade2", "fadei", "fader", "fadel", "fade8", "mancha", "mancha2", "1", "2", "3", "4", "5", "6"];
		for (i in 0...tl.numChildren) {
			var m = Std.downcast(tl.getChildAt(i), MovieClip);
			if (m == null || m.name == null || special.indexOf(m.name) >= 0 || m.name.indexOf("instance") == 0) {
				continue;
			}
			obs.push(makeObs(m));
		}
		var m1 = mcOf("mancha");
		var m2 = mcOf("mancha2");
		var sh1:Shot = null;
		var sh2:Shot = null;
		if (m1 != null) {
			sh1 = new Shot(m1);
			shots.push(sh1);
			zmap.set(m1, 999);
		}
		if (m2 != null) {
			sh2 = new Shot(m2);
			shots.push(sh2);
			zmap.set(m2, 998);
		}
		for (o in obs) {
			if (o.name == "pantano1") {
				o.mancha = sh1;
			} else if (o.name == "pantano2") {
				o.mancha = sh2;
			}
		}

		findHud();
		var fd = mcOf("fade");
		if (fd != null) {
			zmap.set(fd, 2000);
		}
		if (hud != null) {
			zmap.set(hud, 1000);
		}
		if (obs.length == 0) {
			errText = "AVISO: no se encontraron obstaculos en el fotograma " + cur;
		}
	}

	function makeObs(m:MovieClip):Obs {
		var o = new Obs();
		o.mc = m;
		o.name = m.name;
		m.stop();
		m.gotoAndStop(1);
		o.total = m.totalFrames;
		o.snack = (o.name.indexOf("snack") == 0);
		o.atajo = (o.name.indexOf("atajo") == 0);
		o.tr = placed("obs_" + o.name, m);
		var hr = m.getChildByName("hit");
		o.hitRect = hr;
		var hm = (hr == null) ? null : Std.downcast(hr, MovieClip);
		if (hm != null && hm.totalFrames == 1) {
			hr.alpha = 0; // rectangulo de colision (en el original: _visible = 0)
		}
		o.shadow = m.getChildByName("sombra");
		if (o.total == 36) {
			o.hitFrame = 27;
			o.appearEnd = 26;
		} else if (o.total == 31) {
			o.hitFrame = 20;
			o.appearEnd = 19;
		}
		o.sc = scale1;
		m.scaleX = m.scaleY = scale1 / 100;
		m.visible = false;
		cacheMc(m);
		return o;
	}

	function findHud():Void {
		hudLives = null;
		hudEnergy = null;
		hudLevel = null;
		hudTimer = null;
		hudNeedle = null;
		hudScoreTf = [];
		hudTimeTf = [];
		if (hud == null) {
			return;
		}
		var last:MovieClip = null;
		for (i in 0...hud.numChildren) {
			var c = hud.getChildAt(i);
			var t = Std.downcast(c, TextField);
			var m = Std.downcast(c, MovieClip);
			if (t != null) {
				hudScoreTf.push(t);
			} else if (m != null) {
				last = m;
				switch (m.totalFrames) {
					case 4:
						hudLives = m;
					case 15:
						hudTimer = m;
					case 7:
						hudEnergy = m;
					case 3:
						hudLevel = m;
					default:
				}
			}
		}
		hudNeedle = last;
		if (hudTimer != null) {
			hudTimer.stop();
			for (i in 0...hudTimer.numChildren) {
				var t = Std.downcast(hudTimer.getChildAt(i), TextField);
				if (t != null) {
					hudTimeTf.push(t);
				}
			}
		}
		if (hudLevel != null) {
			hudLevel.gotoAndStop(nivel);
		}
	}

	function tickPlay():Void {
		if (car == null) {
			return;
		}
		for (s in stripes) {
			updateStripe(s);
		}
		updateSombra();
		for (o in obs) {
			updateObs(o);
		}
		if (mode != M_PLAY) {
			return; // el nivel termino dentro de updateObs (sin fundido)
		}
		for (sh in shots) {
			sh.tick();
		}
		updateBrake();
		updateDirector();
		updateCar();
		updateHud();
		sortDepth();
	}

	// ---- aros(): rayas de la carretera ----
	function updateStripe(s:MovieClip):Void {
		var idx = stripes.indexOf(s);
		var tr = stripeTr[idx];
		var sc = s.scaleX * 100;
		if (sc < scale2) {
			sc += sc / acelera;
		} else {
			sc = scale1 + scale1 / acelera;
		}
		s.scaleX = s.scaleY = sc / 100;
		zmap.set(s, sc);
		var ex = sc + sc / acelera;
		if (curva == 1) {
			s.x = (s.x > ex + 30) ? s.x - velc : ex + 30;
		} else if (curva == 2) {
			s.x = (s.x < ancho - (ex + 30)) ? s.x + velc : ancho - (ex + 30);
		} else if (curva == 3) {
			s.y = (s.y > ex + 30) ? s.y - velc : ex + 30;
		} else if (curva == 4) {
			s.y = (s.y < ancho - (ex + 150)) ? s.y + velc : ancho - (ex + 150);
		} else {
			approach(s, tr.x, tr.y);
		}
	}

	function approach(d:DisplayObject, xi:Float, yi:Float):Void {
		if (d.x < xi - velc) {
			d.x += velc;
		} else if (d.x > xi + velc) {
			d.x -= velc;
		} else {
			d.x = xi;
		}
		if (d.y < yi - velc) {
			d.y += velc;
		} else if (d.y > yi + velc) {
			d.y -= velc;
		} else {
			d.y = yi;
		}
	}

	// ---- sombra del auto (sprite 206) ----
	function updateSombra():Void {
		if (sombra == null) {
			return;
		}
		zmap.set(sombra, depth);
		if (curva == 1) {
			if (sombra.x > 60) {
				sombra.x -= velc;
			}
		} else if (curva == 2) {
			if (sombra.x < ancho - 80) {
				sombra.x += velc;
			}
		} else if (curva == 3) {
			if (sombra.y > 100) {
				sombra.y -= velc;
			}
		} else if (curva == 4) {
			if (sombra.y < alto - 100) {
				sombra.y += velc;
			}
		} else {
			approach(sombra, sombraTr.x, sombraTr.y);
		}
	}

	// ---- controlador de freno (sprite 86 en profundidad 142) ----
	function updateBrake():Void {
		if (freno < 50) {
			frenar = 1;
		}
		var braking = (keyDown || btnBrake.down) && curva == 0 && frenar != 0 && choque != 1;
		Snd.brake(braking);
		if (braking) {
			if (freno < 100) {
				freno += 1;
			} else {
				frenar = 0;
			}
			if (chispas != null) {
				chispasF = (chispasF < 5) ? chispasF + 1 : 2;
				gf(chispas, chispasF);
			}
			acelera = minimo;
		} else {
			if (freno > 0) {
				freno -= 1;
			}
			chispasF = 1;
			if (chispas != null) {
				gf(chispas, 1);
			}
			if (choque != 1) {
				acelera = maximo;
			} else if (acelera > maximo) {
				acelera -= 1;
				var s = car.scaleX * 100;
				if (s > carTr.sx * 100) {
					setCarScale(s - 0.5);
				}
			} else {
				choque = 0;
			}
		}
	}

	// ---- director del nivel (sprite 86 en profundidad 144) ----
	function updateDirector():Void {
		cuenta += Std.int(20 / acelera);
		var list = LevelData.events[level - 1];
		for (e in list) {
			if (cuenta > e.a && cuenta < e.b) {
				for (n in e.sale) {
					for (o in obs) {
						if (o.name == n) {
							o.sale = true;
						}
					}
				}
				if (e.fast) {
					acelera = maximo;
				}
				if (e.curva >= 0) {
					curva = e.curva;
				}
				if (e.win && !levelEnding) {
					gana = 1;
					endLevel();
				}
				break;
			}
		}
	}

	// ---- obstaculos() ----
	function updateObs(o:Obs):Void {
		if (!o.sale) {
			stepObs(o);
			return;
		}
		o.mc.visible = true;
		if (o.appearEnd > 0 && o.mostro == 0) {
			var lo:Float = (o.total == 36) ? 40 : 5;
			var hi:Float = (o.total == 36) ? 70 : 10;
			if (o.sc > lo && o.sc < hi) {
				o.mostro = 1;
				o.state = 1;
				if (o.name.indexOf("zombie") == 0) {
					Snd.play(242);
				}
				o.f = 2;
			}
		}
		if (o.sc < scale3) {
			o.sc += o.sc / acelera;
			if (o.shadow != null) {
				o.shadow.alpha = Math.max(0, (100 - o.sc) / 100);
			}
		} else {
			resetObs(o);
			return;
		}
		if (o.sc > 160 && o.sc < 180 && o.h == 0 && o.hitRect != null && carHit != null && o.hitRect.hitTestObject(carHit)) {
			onHit(o);
		}
		if (o.h == 0 && o.sc > 250 && o.punt == 0 && !o.snack) {
			o.punt = 1;
			puntos += 10;
			Snd.play(128);
			react(Std.random(2) != 1 ? "bien1" : "bien2");
		}
		if (o.sc > 490) {
			o.alpha100 -= 20;
		} else {
			o.alpha100 = 100;
		}
		o.mc.alpha = Math.max(0, o.alpha100 / 100);
		o.mc.scaleX = o.mc.scaleY = o.sc / 100;
		zmap.set(o.mc, o.sc + (o.abajo ? depth / 2 : depth));
		stepObs(o);
	}

	function resetObs(o:Obs):Void {
		o.sale = false;
		o.h = 0;
		o.punt = 0;
		o.mostro = 0;
		o.abajo = false;
		o.state = 0;
		o.f = 1;
		o.alpha100 = 100;
		o.sc = scale1 + scale1 / acelera;
		o.mc.visible = false;
		o.mc.alpha = 1;
		o.mc.scaleX = o.mc.scaleY = o.sc / 100;
		o.mc.gotoAndStop(1);
		o.lastFrame = 1;
		zmap.set(o.mc, o.sc + depth);
	}

	function stepObs(o:Obs):Void {
		var want = 1;
		if (o.state == 1) {
			want = o.f;
			if (o.f < o.appearEnd) {
				o.f++;
			}
		} else if (o.state == 2) {
			want = o.f;
			if (o.total == 4) {
				o.f = (o.f >= 4) ? 3 : o.f + 1;
			} else if (o.f < o.total) {
				o.f++;
			}
		}
		if (want != o.lastFrame) {
			o.mc.gotoAndStop(want);
			o.lastFrame = want;
		}
	}

	function startHit(o:Obs):Void {
		o.state = 2;
		o.f = o.hitFrame;
		if (o.total == 36) {
			o.abajo = true;
		}
		if (o.name.indexOf("pantano") == 0) {
			o.abajo = true;
			if (o.mancha != null) {
				o.mancha.start();
			}
		}
	}

	function onHit(o:Obs):Void {
		Snd.play(hitSound(o.name));
		if (!o.snack) {
			react(Std.random(2) != 1 ? "mal1" : "mal2");
			if (!o.atajo) {
				if (energia > 1) {
					energia -= 1;
				} else {
					endLevel();
				}
			} else {
				shortcut = 1;
				gana = 1;
				endLevel();
			}
			choque = 1;
			acelera = minimo * 2.5;
			setCarScale(car.scaleX * 100 + 20);
			o.h = 1;
			startHit(o);
		} else {
			startHit(o);
			o.h = 1;
			if (energia < 4) {
				energia += 1;
				react("snack");
			} else {
				puntos += 10;
				Snd.play(128);
				react("bien1");
			}
		}
	}

	function react(label:String):Void {
		persSound(label);
		if (pers != null) {
			pers.gotoAndStop(label);
			lastPers = label;
		}
		reactTimer = 20;
		bien = 1;
	}

	function setPers(label:String):Void {
		if (pers != null && lastPers != label) {
			pers.gotoAndStop(label == "" ? 1 : label);
			lastPers = label;
			persSound(label);
		}
	}

	function setCarScale(percent:Float):Void {
		car.scaleX = car.scaleY = percent / 100;
	}

	// ---- auto (sprite 162 en profundidad 146) ----
	function updateCar():Void {
		zmap.set(car, depth * 2 - 5);
		if (reactTimer > 0) {
			reactTimer--;
			if (reactTimer == 0) {
				bien = 0;
			}
		}
		if (keyLeft || btnLeft.down) {
			target = 50;
			accel = 0.7;
			convert = 0.1;
		} else if (keyRight || btnRight.down) {
			target = -50;
			accel = 0.7;
			convert = 0.1;
		} else if (curva != 1 && curva != 2) {
			target = 0;
			accel = 0.9;
			convert = aconvert;
		}
		rot = rot * accel + (target - car.rotation) * convert;
		car.rotation = car.rotation + rot;

		var sx = car.scaleX * 100;
		var scaleini = carTr.sx * 100;
		if (curva == 1) {
			setPers("derecha");
			target = 25;
			accel = 0.9;
			if (car.x > 60) {
				car.x -= velc;
				convert = 0.006;
			} else {
				convert = 0.1;
			}
		} else if (curva == 2) {
			setPers("izquierda");
			target = -25;
			accel = 0.9;
			if (car.x < ancho - 80) {
				convert = 0.006;
				car.x += velc;
			} else {
				convert = 0.1;
			}
		} else if (curva == 3) {
			setPers("sube");
			if (sx < 150) {
				setCarScale(sx + velc);
			}
		} else if (curva == 4) {
			setPers("baja");
			if (car.y < alto - 100) {
				car.y += velc;
			}
			if (sx > 65) {
				setCarScale(sx - velc / 4.5);
			}
		} else {
			if (sx > scaleini + velc && choque != 1) {
				setCarScale(sx - velc);
			} else if (sx < scaleini && choque != 1) {
				setCarScale(sx + velc / 4.5);
			} else if (choque != 1) {
				setCarScale(scaleini);
			}
			if (car.x < carTr.x - velc) {
				target = 25;
				accel = 0.9;
				aconvert = 0.003;
				car.x += velc;
			} else if (car.x > carTr.x + velc) {
				target = -25;
				accel = 0.9;
				aconvert = 0.003;
				car.x -= velc;
			} else {
				aconvert = 0.1;
				car.x = carTr.x;
			}
			if (car.y < carTr.y - velc) {
				car.y += velc;
			} else if (car.y > carTr.y + velc) {
				car.y -= velc;
			} else {
				car.y = carTr.y;
			}
		}
		if (curva == 0 && choque == 0 && bien == 0) {
			setPers("");
		}
	}

	// ---- HUD (sprite 295) y temporizador (sprite 268, 15 fotogramas) ----
	function updateHud():Void {
		timerTick++;
		if (timerTick >= 15) {
			timerTick = 0;
			if (tiempo > 0) {
				if (perder != 1) {
					tiempo -= 1;
				}
			} else {
				endLevel();
			}
		}
		var sp = Std.string(puntos);
		if (sp != lastSp) {
			lastSp = sp;
			for (t in hudScoreTf) {
				t.text = sp;
			}
		}
		var st = Std.string(tiempo);
		if (st != lastTm) {
			lastTm = st;
			for (t in hudTimeTf) {
				t.text = st;
			}
		}
		if (hudLives != null) {
			gf(hudLives, vidas < 1 ? 1 : vidas);
		}
		if (hudEnergy != null) {
			gf(hudEnergy, energia < 1 ? 1 : energia);
		}
		if (hudNeedle != null) {
			hudNeedle.rotation = freno * 360 / 100;
		}
	}

	function sortDepth():Void {
		var items:Array<{d:DisplayObject, z:Float}> = [];
		for (i in 0...tl.numChildren) {
			var c = tl.getChildAt(i);
			var zz = zmap.get(c);
			var z:Float = (zz == null) ? (-1000.0 + i) : zz;
			items.push({d: c, z: z});
		}
		items.sort(function(a, b) return (a.z < b.z) ? -1 : ((a.z > b.z) ? 1 : 0));
		for (i in 0...items.length) {
			if (tl.getChildIndex(items[i].d) != i) {
				tl.setChildIndex(items[i].d, i);
			}
		}
	}

	// ---- fin de nivel: fotogramas 15 y 16/22/28 ----
	function endLevel():Void {
		if (levelEnding) {
			return;
		}
		levelEnding = true;
		fadeAnim.exit(afterLevel);
	}

	function afterLevel():Void {
		if (gana != 1) {
			perder = 1;
			if (vidas > 1) {
				vidas -= 1;
			} else {
				over = 1;
			}
		} else {
			ganar = 1;
			gana = 0;
		}
		if (ganar == 1) {
			ganar = 0;
			if (shortcut == 1) {
				shortcut = 0;
				go(37);
			} else if (nivel == 1) {
				go(19);
			} else if (nivel == 2) {
				go(25);
			} else {
				go(31);
			}
		} else if (over == 1) {
			over = 0;
			go(32 + nivel);
		} else {
			perder = 0;
			go(nivel == 1 ? 17 : (nivel == 2 ? 23 : 29));
		}
	}
}
